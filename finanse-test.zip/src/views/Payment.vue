<template>
  <div class="page">
    <div class="pay">
      <div class="pay__buying">
        <div class="h5">You are buying</div>

        <div class="pay__buying-info">
          <div class="h5">You are buying</div>
          <div>
            <div>Flight in space /Jupiter Area</div>
            <div>From IO to GANIMED, J29, 2048, G5/42 </div>
            <div>Spaceship "Queen of the Sun"</div>
          </div>
        </div>

        <div class="pay__buying-price">
          <div><span>42350.00</span> USD</div>
          <div>Amount to pay without the payment system commission</div>
        </div>

        <div class="pay__buying-seller">
          <div class="h5">Seller</div>

          <div>National Aeronautics and Space Administration (NASA)
          Headquarters 300 E. Street SW, Suite 5R30</div>

          <div class="pay__buying-seller-rating">
            <div>Rating: <span>5</span></div>
            <div>Reviews: <span>308 042</span></div>
          </div>
        </div>
      </div>

      <div class="pay__methods">
        <div class="pay__methods-head">
          <div class="h2">Payment method</div>
        </div>

        <div class="pay__methods-nav">
          <div 
            v-for="(type, index) in paymentTypes" 
            :key="index"
            class="pay__methods-nav-item"
            :class="{'active': type.active}"
            @click="makeTypeActive(type)"
          >{{ type.title }}</div>
        </div>

        <div class="pay__methods-list">
          <div v-for="(method, index) in paymentMethods" :key="index" class="pay__methods-item">

          </div>
        </div>
      </div>
    </div>

    <a href="https://onpay.ru/" target="_blank" class="provided">Provided by Onpay.ru</a>
  </div>
</template>

<script>
import {mapGetters} from "vuex";

export default {
  data: () => ({
    loading: true,
    searchUsersValue: '',

    dialogUserDelete: false,
    dialogUserForm: false,
    dialogUserFormType: '',

    user: {},

    page: 1,
    perPage: 4,
    pageCount: 0
  }),

  computed: {
    ...mapGetters({
      payments: "payments/data",
    }),

    paymentTypes() {
      let result = []
      
      this.payments.forEach(payment => {
        if ( result.every(elem => elem.title != payment.type) ) {
          result.push({
            title: payment.type,
            active: false
          })
        }
      })

      result[0].active = true

      return result
    },

    paymentMethods() {
      
    }
  },

  methods: {
  },

  created() {
    this.$store.dispatch('payments/getPayments')

    console.log(this.paymentTypes)
  }
}
</script>
